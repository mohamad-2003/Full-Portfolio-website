<?php
require_once('../connection/db.php');
//INSERTING DATA
$sql="INSERT INTO hero_section(title, subtitle, image_url) VALUES (:title,:subtitle,:image_url)";
$stmt=$pdo->prepare($sql);

$stmt->execute([
    'title'=>'hello dear',
    'subtitle'=>'Empowering Connections and Showcasing Creativity.',
    'image_url'=>'/design/logo.jpeg'
]);
echo"hero section inserted was done";
?>