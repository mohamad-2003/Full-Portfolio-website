<?php
require_once('../connection/db.php');
include('../herosection/inserting.php');

// FETCHING DATA
$sql = "SELECT * FROM hero_section";
$stmt = $pdo->query($sql);
$heroes = $stmt->fetchAll(PDO::FETCH_ASSOC);  // Fetch all rows

// DISPLAYING DATA
foreach ($heroes as $hero) {
    echo "<div class='hero'>";
    echo "<h1>" . htmlspecialchars($hero['title']) . "</h1>";
    echo "<p>" . htmlspecialchars($hero['subtitle']) . "</p>";
    echo "<img src='" . $hero['image_url'] . "' alt='Hero Image'>";
    echo "</div>";
}
?>
