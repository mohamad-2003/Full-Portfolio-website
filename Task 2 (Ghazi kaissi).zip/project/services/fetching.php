<?php
require_once('../connection/db.php');
include('../services/inserting.php');
 $sql="SELECT * FROM services";

 $stmt=$pdo->query($sql);

 $services=$stmt->fetchALL (PDO::FETCH_ASSOC);

 foreach($services as $service){
    echo "<div class='service'>";
    echo "<h3>" . $service['service_name'] . "</h3>";
    echo "<p>" . $service['description'] . "</p>";
    echo "<img src='" . $service['image_url'] . "' alt='Service Image'>";
    echo "</div>";
}
?>