<?php
// Database configuration
$dsn = "mysql:host=127.0.0.1;dbname=project";
$username = "root";
$password = "";

try {
    // PDO instance
    $pdo = new PDO($dsn, $username, $password);
    
    // For error handling
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Connected successfully!";
} catch (PDOException $e) {
    // If we have an error, give me a message
    echo "Connection failed: " . $e->getMessage();
}
?>
