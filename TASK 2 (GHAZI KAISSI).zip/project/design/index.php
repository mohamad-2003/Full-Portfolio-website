<?php
require_once('../functions/functions.php');
$navbarLinks = FetchNav($pdo);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>task1</title>
    <!-- Bootstrap 4.5.2 CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <nav class="navbar navbar-expand-lg bg-dark border-bottom border-body" data-bs-theme="dark">
    <div class="container-fluid">
      <a class="navbar-brand text-light" href="#"><img src="logo.jpeg" alt="Logo" width="30" height="24" class="d-inline-block align-text-top"> M:G</a>

      <!-- Navbar Toggler for Mobile View -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar Links -->
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
       
        <ul class="navbar-nav ml-auto mb-2 mb-lg-0">
        <?php
                    foreach ($navbarLinks as $link) {
                        echo "<li class='nav-item'><a class='nav-link text-light' href='" . htmlspecialchars($link['url']) . "'>" . htmlspecialchars($link['title']) . "</a></li>";
                    }
                    ?>
                </ul>
            </div>

      <!-- Search Form -->
      <form class="form-inline d-flex" role="search">
        <input class="form-control mr-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-success" type="submit">Search</button>
      </form>

      <!-- User Icon -->
      <div class="user-icon">
        <a href="#">
          <img src="https://via.placeholder.com/30" alt="User Icon" class="rounded-circle">
        </a>
      </div>
    </div>
  </nav>

  <!-- Button Group with Spacing -->
  <div class="container mt-5">
    <h3>Button Group with Spacing</h3>
    <div class="btn-group">
      <button type="button" class="btn btn-primary mr-4">Left</button>
      <button type="button" class="btn btn-danger mr-4">Middle</button>
      <button type="button" class="btn btn-primary">Right</button>
    </div>
  </div>

  <!-- Bootstrap JS (for navbar toggling) -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
