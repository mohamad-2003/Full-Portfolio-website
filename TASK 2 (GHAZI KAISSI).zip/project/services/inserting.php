<?php
require_once('../connection/db.php');
//INSERTING DATA
$sql="INSERT INTO services (service_name, description, image_url) VALUES (:service_name,:description,:image_url)";

$stmt=$pdo->prepare($sql);

$stmt->execute([
    'service_name'=>'we offered lot of things',
    'description'=>'go to our website home page to take a look',
    'image_url'=>'/design/logo.jpeg'
]);
echo"data inserted succesfully!";
?>