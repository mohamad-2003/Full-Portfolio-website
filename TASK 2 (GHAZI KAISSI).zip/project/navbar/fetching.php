<?php
require_once('../connection/db.php');

// Fetch data from the table
$sql = "SELECT * FROM navbar";
$stmt = $pdo->query($sql);
$stmt->execute(); // Execute the statement
$navbarLinks = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Display navbar links
echo "<ul class='navbar'>";
foreach ($navbarLinks as $link) {
    echo "<li><a href='" . $link['url'] . "'>" . $link['title'] . "</a></li>";
}
echo "</ul>";
?>