<?php
require_once('../connection/db.php');
//TO INSERT DATA
$sql="INSERT INTO navbar(title,url) VALUES (:title,:url)";

//PREPARE

$stmt=$pdo->prepare($sql);

//EXECUTION

//for home
$stmt->execute([
    'title'=>"Home",
    'url'=>"/Home"
]);
//about
$stmt->execute([
    'title'=>"About",
    'url'=>'/About'
]);
//number
$stmt->execute([
    'title'=>"Number",
    'url'=>'/Number'
]);
//portfolio
$stmt->execute([
    'title'=>"Portfolio",
    'url'=>'/Portfolio'
]);
//address
$stmt->execute([
    'title'=>"Address",
    'url'=>'/Address'
]);
//contact
$stmt->execute([
    'title'=>"Contact",
    'url'=>'/Contact'
]); 

echo"data in navbar inserted succesfully!";


?>
