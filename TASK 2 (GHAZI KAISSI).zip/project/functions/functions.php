<?php
//CONNECTION TO DATABASE
require_once('../connection/db.php');

//INSERTING DATA TO NAVBAR
function InsertNav($pdo,$title,$url){
$sql="INSERT INTO navbar (title,url) VALUES (:title,:url)";
$stmt=$pdo->prepare($sql);
$stmt->execute([
    'title'=>$title,
    'url'=>$url
]);
}

//FETCHING DATA FROM NAVBAR

function FetchNav($pdo){
$sql="SELECT * FROM navbar";
$stmt=$pdo->query($sql);
return $stmt->fetchAll(PDO::FETCH_ASSOC);

}

?>